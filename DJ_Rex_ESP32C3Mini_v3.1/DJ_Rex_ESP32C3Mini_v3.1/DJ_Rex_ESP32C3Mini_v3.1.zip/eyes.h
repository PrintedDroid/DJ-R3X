#ifndef EYES_H
#define EYES_H

#include "config.h"
#include "globals.h"

void initializeEyes();
void updateEyes();

// NEW: Function to display eye flicker settings
void printEyeFlickerSettings();

#endif