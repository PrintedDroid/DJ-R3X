#ifndef DEMO_H
#define DEMO_H

#include "config.h"
#include "globals.h"

void handleDemoMode();

#endif